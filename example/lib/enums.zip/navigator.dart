import 'package:flutter/material.dart';

class CustomNavigator {
  
  Widget returnBar() {
    if (true) {
      
    }
  }
}
